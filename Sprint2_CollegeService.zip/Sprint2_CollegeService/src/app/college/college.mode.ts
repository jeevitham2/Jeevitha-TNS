export interface College {
    id?:number;
    name:string;
    address:string;
    accreditation:string;
    establishedDate:Date;

}
